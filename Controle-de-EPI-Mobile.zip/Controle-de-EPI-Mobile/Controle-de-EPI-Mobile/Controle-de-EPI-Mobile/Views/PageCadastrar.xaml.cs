﻿using Controle_de_EPI_Mobile;
using ControledeEPIMobile.Models;
using ControledeEPIMobile.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ControledeEPIMobile.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PageCadastrar : ContentPage
    {
        public PageCadastrar()
        {
            InitializeComponent();

            var options = new string[]
            {
                "Matutino",
                "Vespertino",
                "Noturno"
            };

            foreach (var option in options)
            {
                cbxTurno.Items.Add(option);
            }

            cbxTurno.SelectedIndexChanged += Picker_SelectedIndexChanged;
        }

        public PageCadastrar(ModelFuncionarios nota)
        {
            InitializeComponent();
            btSalvar.Text = "Alterar";
            txtCodigo.IsVisible = true;
            btExcluir.IsVisible = true;
            txtCodigo.Text = nota.Id.ToString();
            txtmatricula.Text = nota.matricula;

            var options = new string[] { "Matutino", "Vespertino", "Noturno" };
            foreach (var option in options)
            {
                cbxTurno.Items.Add(option);
            }

            cbxTurno.SelectedItem = nota.EPI;

            nota.dataEntrega = DateTime.Now;
            nota.dataVencimento = DateTime.Now; ;
        }

        private void Picker_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedOption = cbxTurno.Items[cbxTurno.SelectedIndex];

            DisplayAlert("Selecionado", $"Opção selecionada: {selectedOption}", "OK");
        }

        private void btCancelar_Clicked_1(object sender, EventArgs e)
        {
            MasterDetailPage p = (MasterDetailPage)Application.Current.MainPage;
            p.Detail = new NavigationPage(new PageHome());
        }

        private async Task btExcluir_Clicked_1Async(object sender, EventArgs e)
        {
            var resp = await DisplayAlert("Excluir Funcionario", "Deseja EXCLUIR este funcionario selecionado?", "Sim", "Não");
            if (resp == true)
            {
                ServiceDBFuncs dBNotas = new ServiceDBFuncs(App.DbPath);
                int id = Convert.ToInt32(txtCodigo.Text);
                dBNotas.Excluir(id);
                DisplayAlert("Funcionario excluído com sucesso", dBNotas.StatusMessage, "OK");
                MasterDetailPage p = (MasterDetailPage)Application.Current.MainPage;
                p.Detail = new NavigationPage(new PageHome());
            }
        }

        private void btSalvar_Clicked_1(object sender, EventArgs e)
        {
            try
            {
                ModelFuncionarios notas = new ModelFuncionarios();
                notas.matricula = txtmatricula.Text;
                notas.EPI = cbxTurno.SelectedItem.ToString();
                notas.dataEntrega = DateTime.Now;
                notas.dataVencimento = DateTime.Now;

                ServiceDBFuncs dBNotas = new ServiceDBFuncs(App.DbPath);
                if (btSalvar.Text == "Inserir")
                {
                    dBNotas.Inserir(notas);
                    DisplayAlert("Resultado", dBNotas.StatusMessage, "OK");
                }
                else
                {
                    notas.Id = Convert.ToInt32(txtCodigo.Text);
                    dBNotas.Alterar(notas);
                    DisplayAlert("Funcionario alterado com sucesso!", dBNotas.StatusMessage, "OK");
                }
                MasterDetailPage p = (MasterDetailPage)Application.Current.MainPage;
                p.Detail = new NavigationPage(new PageHome());
            }
            catch (Exception ex)
            {
                DisplayAlert("Erro", ex.Message, "OK");
            }
        }
    }
}