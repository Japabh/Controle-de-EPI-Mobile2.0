﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;


using Controle_de_EPI_Mobile;
using ControledeEPIMobile.Models;
using ControledeEPIMobile.Services;

namespace ControledeEPIMobile.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PageEPI : ContentPage
    {
        public PageEPI()
        {
            InitializeComponent();

            var options = new string[]
            {
                "EPI 1",
                "EPI 2",
                "EPI 3"
            };

            foreach (var option in options)
            {
                cbxTier.Items.Add(option);
            }

            cbxTier.SelectedIndexChanged += Picker_SelectedIndexChanged;
        }

        public PageEPI(ModelEPI nota)
        {
            InitializeComponent();
            btSalvar.Text = "Alterar";
            txtmatricula.IsVisible = true;
            btExcluir.IsVisible = true;
            txtmatricula.Text = nota.Id.ToString();
            txtEPI  .Text = nota.material;

            var options = new string[] { "EPI 1", "EPI 2", "EPI 3" };
            foreach (var option in options)
            {
                cbxTier.Items.Add(option);
            }

            cbxTier.SelectedItem = nota.EPI;

            txtDesc.Text = nota.Desc;
        }

        private void btSalvar_Clicked(object sender, EventArgs e)
        {
            try
            {
                ModelEPI notas = new ModelEPI();
                notas.material = txtEPI.Text;
                notas.EPI = cbxTier.SelectedItem.ToString();
                notas.Desc = txtDesc.Text;
                ServiceDBEPI dBNotas = new ServiceDBEPI(App.DbPath);
                if (btSalvar.Text == "Inserir")
                {
                    dBNotas.Inserir(notas);
                    DisplayAlert("Resultado", dBNotas.StatusMessage, "OK");
                }
                else
                {
                    notas.Id = Convert.ToInt32(txtmatricula.Text);
                    dBNotas.Alterar(notas);
                    DisplayAlert("EPI alterado com sucesso!", dBNotas.StatusMessage, "OK");
                }
                MasterDetailPage p = (MasterDetailPage)Application.Current.MainPage;
                p.Detail = new NavigationPage(new PageHome());
            }
            catch (Exception ex)
            {
                DisplayAlert("Erro", ex.Message, "OK");
            }
        }

        private async void btExcluir_Clicked(object sender, EventArgs e)
        {
            var resp = await DisplayAlert("Excluir EPI", "Deseja EXCLUIR este EPI selecionado?", "Sim", "Não");
            if (resp == true)
            {
                ServiceDBEPI dBNotas = new  ServiceDBEPI(App.DbPath);
                int id = Convert.ToInt32(txtmatricula.Text);
                dBNotas.Excluir(id);
                DisplayAlert("EPI excluído com sucesso", dBNotas.StatusMessage, "OK");
                MasterDetailPage p = (MasterDetailPage)Application.Current.MainPage;
                p.Detail = new NavigationPage(new PageHome());
            }
        }    

        private void btCancelar_Clicked(object sender, EventArgs e)
        {
            MasterDetailPage p = (MasterDetailPage)Application.Current.MainPage;
            p.Detail = new NavigationPage(new PageHome());
        }

        private void Picker_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedOption = cbxTier.Items[cbxTier.SelectedIndex];

            DisplayAlert("Selecionado", $"Opção selecionada: {selectedOption}", "OK");
        }
    }
}