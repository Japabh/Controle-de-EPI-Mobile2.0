﻿using Controle_de_EPI_Mobile;
using ControledeEPIMobile.Models;
using ControledeEPIMobile.Services;
using ControledeEPIMobile.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ControledeEPIMobile.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PageListar : ContentPage
    {
        private bool ListarEPI = false; // Variável para controlar o estado do Switch

        public PageListar()
        {
            InitializeComponent();
            AtualizaLista();
        }

        public void AtualizaLista()
        {
            if (ListarEPI)
            {
                // Listar setores
                ServiceDBEPI dBSetor = new ServiceDBEPI(App.DbPath);
                ListaFuncs.ItemsSource = dBSetor.Listar();
            }
            else
            {
                // Listar funcionários
                ServiceDBFuncs dBFuncionario = new ServiceDBFuncs(App.DbPath);
                string matricula = "";
                if (!string.IsNullOrEmpty(txtmatricula.Text))
                    matricula = txtmatricula.Text;
                ListaFuncs.ItemsSource = dBFuncionario.Localizar(matricula);
            }
        }

        private void btLocalizar_Clicked(object sender, EventArgs e)
        {
            AtualizaLista();
        }

        private void ListaFuncs_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (ListarEPI)
            {
                ModelEPI EPI = (ModelEPI)e.SelectedItem;
                MasterDetailPage p = (MasterDetailPage)Application.Current.MainPage;
                p.Detail = new NavigationPage(new PageEPI(EPI));
            }
            else
            {
                // Manipular seleção de funcionário
                ModelFuncionarios funcionario = (ModelFuncionarios)e.SelectedItem;
                MasterDetailPage p = (MasterDetailPage)Application.Current.MainPage;
                p.Detail = new NavigationPage(new PageCadastrar(funcionario));
            }
        }

        private void switchListarSetores_Toggled(object sender, ToggledEventArgs e)
        {
            // Altera o estado do Switch e atualiza a lista
            ListarEPI = e.Value;
            AtualizaLista();
        }
    }
}
