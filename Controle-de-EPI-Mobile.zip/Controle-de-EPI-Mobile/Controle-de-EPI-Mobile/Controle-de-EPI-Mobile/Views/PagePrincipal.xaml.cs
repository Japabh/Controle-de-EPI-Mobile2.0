﻿using Controle_de_EPI_Mobile;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ControledeEPIMobile.Views;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ControledeEPIMobile.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PagePrincipal : MasterDetailPage
    {
        public PagePrincipal()
        {
            InitializeComponent();
            // Definindo a página inicial
            Detail = new NavigationPage(new PageHome());
        }

        private void btHome_Clicked(object sender, EventArgs e)
        {
            Detail = new NavigationPage(new PageHome());
            IsPresented = false; // Oculta o menu lateral após a navegação
        }

        private void btCadastrar_Clicked(object sender, EventArgs e)
        {
            Detail = new NavigationPage(new PageCadastrar());
            IsPresented = false;
        }

        private void btLocalizar_Clicked(object sender, EventArgs e)
        {
            Detail = new NavigationPage(new PageListar());
            IsPresented = false;
        }

        private void btSobre_Clicked(object sender, EventArgs e)
        {
            Detail = new NavigationPage(new PageSobre());
            IsPresented = false;
        }

        private void btEPI_Clicked(object sender, EventArgs e)
        {
            Detail = new NavigationPage(new PageEPI());
            IsPresented = false;
        }
    }
}
