﻿using Controle_de_EPI_Mobile;
using SQLite;
using System;
using System.Collections.Generic;
using System.Text;
using ControledeEPIMobile.Models;

namespace ControledeEPIMobile.Services
{
    internal class ServiceDBEPI
    {
        SQLiteConnection conn;
        public string StatusMessage { get; set; }
        public ServiceDBEPI(string dbPath)
        {
            if (dbPath == "") dbPath = App.DbPath;
            conn = new SQLiteConnection(dbPath);
            conn.CreateTable<ModelEPI>();
        }
        public void Inserir(ModelEPI nota)
        {
            try
            {
                if (string.IsNullOrEmpty(nota.material))
                    throw new Exception("Material não informado!");
 
                // Convertendo DataVencimento e DataEntrega para string
                string dataVencimentoString = nota.DataVencimento.ToString("dd/MM/yyyy");

                string dataEntregaString = nota.dataEntrega.ToString("dd/MM/yyyy");

                int result = conn.Insert(nota);
                if (result != 0)
                {
                    this.StatusMessage = string.Format("{0} registro(s) adicionado(s): [Setor: {1}, Data de Vencimento: {2}, Data de Entrega: {3}]", result, nota.material, dataVencimentoString, dataEntregaString);
                }
                else
                {
                    this.StatusMessage = "0 registro adicionado! Por favor, informe o nome e o Tier do Setor!";
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        public List<ModelEPI> Listar()
        {
            List<ModelEPI> lista = new List<ModelEPI>();
            try
            {
                lista = conn.Table<ModelEPI>().ToList();
                this.StatusMessage = "Listagem dos Setores";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return lista;
        }
        public void Alterar(ModelEPI nota)
        {
            try
            {
                if (string.IsNullOrEmpty(nota.material))
                    throw new Exception("Nome do Setor não informado!");
                if (nota.Id <= 0)
                    throw new Exception("Id do Setor não informado!");
                int result = conn.Update(nota);
                StatusMessage = string.Format("{0} registro alterado!", result);
                string dataVencimentoString = nota.DataVencimento.ToString("dd/MM/yyyy");

                string dataEntregaString = nota.dataEntrega.ToString("dd/MM/yyyy");

            }
            catch (Exception ex)
            {

                throw new Exception(string.Format("Erro: {0}", ex.Message));
            }
        }
        public void Excluir(int id)
        {
            try
            {
                int result = conn.Table<ModelEPI>().Delete(r => r.Id == id);
                StatusMessage = string.Format("{0} registro deletado", result);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Erro: {0}", ex.Message));
            }
        }
        public List<ModelEPI> Localizar(string titulo)
        {
            List<ModelEPI> lista = new List<ModelEPI>();
            try
            {
                var resp = from p in conn.Table<ModelEPI>() where p.material.ToLower().Contains(titulo.ToLower()) select p;
                lista = resp.ToList();

            }
            catch (Exception ex)
            {

                throw new Exception(string.Format("Erro: {0}", ex.Message));
            }
            return lista;
        }
    }
}
