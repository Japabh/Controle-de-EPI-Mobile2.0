﻿using Controle_de_EPI_Mobile;
using ControledeEPIMobile.Models;
using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace ControledeEPIMobile.Services
{
    internal class ServiceDBFuncs
    {
        SQLiteConnection conn;
        public string StatusMessage { get; set; }
        public ServiceDBFuncs(string dbPath)
        {
            if (dbPath == "") dbPath = App.DbPath;
            conn = new SQLiteConnection(dbPath);
            conn.CreateTable<ModelFuncionarios>();
        }
        public void Inserir(ModelFuncionarios nota)
        {
            try
            {
                if (string.IsNullOrEmpty(nota.matricula))
                    throw new Exception("Matrícula do Funcionário não informado!");
                if (string.IsNullOrEmpty(nota.EPI))
                    throw new Exception("EPI do Funcionário não informado!");
                int result = conn.Insert(nota);
                if (result != 0)
                {
                    this.StatusMessage = string.Format("{0} registro(s) adicionado(s): [Funcionário: {1}]", result, nota.matricula);
                }
                else
                {
                    this.StatusMessage = string.Format("0 registro adicionado! Por favor, informe o nome e o setor do funcionário!");
                }

            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }
        public List<ModelFuncionarios> Listar()
        {
            List<ModelFuncionarios> lista = new List<ModelFuncionarios>();
            try
            {
                lista = conn.Table<ModelFuncionarios>().ToList();
                this.StatusMessage = "Listagem dos Funcionários";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return lista;
        }
        public void Alterar(ModelFuncionarios nota)
        {
            try
            {
                if (string.IsNullOrEmpty(nota.matricula))
                    throw new Exception("Matricula do Funcionário não informado!");
                if (string.IsNullOrEmpty(nota.EPI))
                    throw new Exception("EPI do Funcionário não informado!");
                if (nota.Id <= 0)
                    throw new Exception("Id do Funcionário não informado!");
                int result = conn.Update(nota);
                StatusMessage = string.Format("{0} registro alterado!", result);

            }
            catch (Exception ex)
            {

                throw new Exception(string.Format("Erro: {0}", ex.Message));
            }
        }
        public void Excluir(int id)
        {
            try
            {
                int result = conn.Table<ModelFuncionarios>().Delete(r => r.Id == id);
                StatusMessage = string.Format("{0} registro deletado", result);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Erro: {0}", ex.Message));
            }
        }
        public List<ModelFuncionarios> Localizar(string titulo)
        {
            List<ModelFuncionarios> lista = new List<ModelFuncionarios>();
            try
            {
                var resp = from p in conn.Table<ModelFuncionarios>() where p.matricula.ToLower().Contains(titulo.ToLower()) select p;
                lista = resp.ToList();

            }
            catch (Exception ex)
            {

                throw new Exception(string.Format("Erro: {0}", ex.Message));
            }
            return lista;
        }
    }
}
