﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace ControledeEPIMobile.Models
{
    [Table("Funcionarios")]
    public class ModelFuncionarios
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        [NotNull]
        public String matricula { get; set; }
        public String EPI { get; set; }

        [NotNull]
        public DateTime dataEntrega { get; set; }

        [NotNull]
        public DateTime dataVencimento { get; set; }

        public ModelFuncionarios()
        {
            this.Id = 0;
            this.matricula = "";
            this.EPI = "";
            this.dataEntrega = DateTime.Now;
            this.dataVencimento = DateTime.Now;
        }
    }
    public class ModelEPI
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        [NotNull]
        public String material { get; set; }
        public DateTime dataEntrega { get; set; }
        public DateTime DataVencimento { get; set;}
        public string EPI { get; internal set; }
        public string Desc { get; internal set; }

        public ModelEPI()
        {
            this.Id = 0;
            this.material = "";
            this.dataEntrega = DateTime.Now;
            this.DataVencimento = DateTime.Now ;
        }
    }
}
