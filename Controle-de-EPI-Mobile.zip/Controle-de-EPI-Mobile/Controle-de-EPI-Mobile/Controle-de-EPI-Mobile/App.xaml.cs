﻿using ControledeEPIMobile.Views;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Controle_de_EPI_Mobile
{
    public partial class App : Application
    {
        public static String DbName;
        public static String DbPath;
        private string dbPath;
        private string dbName;

        public App(string dbPath)
        {
            InitializeComponent();

            MainPage = new PagePrincipal();
        }

        public App(string dbPath, string dbName)
        {
            this.dbPath = dbPath;
            this.dbName = dbName;
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
